Dear {W_NAME},
Congratulations you won the following item:

{A_TITLE}
Your bid: {A_CURRENTBID}
End time: {A_ENDS}

Goto My {SITENAME} {SITE_URL}user_menu.php

Seller's Information:
{S_NICK} - {S_EMAIL}