User {NAME} ({NICK}),<br>
owner of a buyer account asked to switch to a seller account.<br>
<br>
User's details:<br>
---------------<br>
User ID: {ID}<br>
User Name: {NAME}<br>
User Nick: {NICK}<br>
User E-mail: {EMAIL}