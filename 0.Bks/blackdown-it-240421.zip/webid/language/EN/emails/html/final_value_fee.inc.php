Dear {C_NAME},<br>
<br>
This is an invoice for the payment of the final value fee of {ITEM_NAME}.<br>
<br>
Total payable: {BALANCE}<br>
<br>
Please click on the link below to access to the payment page:<br>
<a href="{LINK}">{LINK}</a><br>
<br>
All activity on your site will be suspended until this is paid