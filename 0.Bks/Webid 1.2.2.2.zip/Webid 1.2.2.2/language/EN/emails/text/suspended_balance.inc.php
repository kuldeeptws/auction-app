Dear {NAME},

Your account on {SITENAME} has been suspended because you have exceeded the maximum debt limit allowed.

Your balance is: {BALANCE}

In order to reactivate your account, you will need to clear your account balance.
Please visit the link below to access the payment page.
{OUTSTANDING}