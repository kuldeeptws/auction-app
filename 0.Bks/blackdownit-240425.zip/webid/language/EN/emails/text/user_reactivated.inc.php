Hello {C_NAME},

This e-mail is to confirm that your {SITENAME} account has been re-activated.
You can now login in to your account and start selling and/or bidding.

See you soon!

Ready To Start Looking?
Visit {SITE_URL}