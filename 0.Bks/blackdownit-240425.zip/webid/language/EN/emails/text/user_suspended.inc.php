Hello {C_NAME},

This e-mail is to alert you that your {SITENAME} account has been suspended.

Please contact us if you have any questions.