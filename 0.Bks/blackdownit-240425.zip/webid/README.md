# WeBid
The official WeBid github fork

Please post bugs at http://bugs.webidsupport.com/

Todo list: https://github.com/renlok/WeBid/wiki/To-DO
