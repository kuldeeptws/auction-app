<div class="box">
					<h4 class="rounded-top"><?php echo ((isset($this->_rootref['L_5142'])) ? $this->_rootref['L_5142'] : ((isset($MSG['5142'])) ? $MSG['5142'] : '{ L_5142 }')); ?></h4>
					<div class="rounded-bottom">
						<ul class="menu">
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/settings.php"><?php echo ((isset($this->_rootref['L_general_settings'])) ? $this->_rootref['L_general_settings'] : ((isset($MSG['general_settings'])) ? $MSG['general_settings'] : '{ L_general_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/auctions.php"><?php echo ((isset($this->_rootref['L_auction_settings'])) ? $this->_rootref['L_auction_settings'] : ((isset($MSG['auction_settings'])) ? $MSG['auction_settings'] : '{ L_auction_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/displaysettings.php"><?php echo ((isset($this->_rootref['L_display_settings'])) ? $this->_rootref['L_display_settings'] : ((isset($MSG['display_settings'])) ? $MSG['display_settings'] : '{ L_display_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/spam.php"><?php echo ((isset($this->_rootref['L_spam_settings'])) ? $this->_rootref['L_spam_settings'] : ((isset($MSG['spam_settings'])) ? $MSG['spam_settings'] : '{ L_spam_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/emailsettings.php"><?php echo ((isset($this->_rootref['L_email_settings'])) ? $this->_rootref['L_email_settings'] : ((isset($MSG['email_settings'])) ? $MSG['email_settings'] : '{ L_email_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/usersettings.php"><?php echo ((isset($this->_rootref['L_user_settings'])) ? $this->_rootref['L_user_settings'] : ((isset($MSG['user_settings'])) ? $MSG['user_settings'] : '{ L_user_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/errorhandling.php"><?php echo ((isset($this->_rootref['L_error_handling'])) ? $this->_rootref['L_error_handling'] : ((isset($MSG['error_handling'])) ? $MSG['error_handling'] : '{ L_error_handling }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/moderation.php"><?php echo ((isset($this->_rootref['L_moderation_settings'])) ? $this->_rootref['L_moderation_settings'] : ((isset($MSG['moderation_settings'])) ? $MSG['moderation_settings'] : '{ L_moderation_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/countries.php"><?php echo ((isset($this->_rootref['L_081'])) ? $this->_rootref['L_081'] : ((isset($MSG['081'])) ? $MSG['081'] : '{ L_081 }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/payments.php"><?php echo ((isset($this->_rootref['L_075'])) ? $this->_rootref['L_075'] : ((isset($MSG['075'])) ? $MSG['075'] : '{ L_075 }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/durations.php"><?php echo ((isset($this->_rootref['L_069'])) ? $this->_rootref['L_069'] : ((isset($MSG['069'])) ? $MSG['069'] : '{ L_069 }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/increments.php"><?php echo ((isset($this->_rootref['L_128'])) ? $this->_rootref['L_128'] : ((isset($MSG['128'])) ? $MSG['128'] : '{ L_128 }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/membertypes.php"><?php echo ((isset($this->_rootref['L_25_0169'])) ? $this->_rootref['L_25_0169'] : ((isset($MSG['25_0169'])) ? $MSG['25_0169'] : '{ L_25_0169 }')); ?></a></li>
						</ul>
					</div>
				</div>
				<div class="box">
					<h4 class="rounded-top"><?php echo ((isset($this->_rootref['L_276'])) ? $this->_rootref['L_276'] : ((isset($MSG['276'])) ? $MSG['276'] : '{ L_276 }')); ?></h4>
					<div class="rounded-bottom">
						<ul class="menu">
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/categories.php"><?php echo ((isset($this->_rootref['L_078'])) ? $this->_rootref['L_078'] : ((isset($MSG['078'])) ? $MSG['078'] : '{ L_078 }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/categoriestrans.php"><?php echo ((isset($this->_rootref['L_132'])) ? $this->_rootref['L_132'] : ((isset($MSG['132'])) ? $MSG['132'] : '{ L_132 }')); ?></a></li>
						</ul>
					</div>
				</div>
				<div class="box">
					<h4 class="rounded-top"><?php echo ((isset($this->_rootref['L_25_0008'])) ? $this->_rootref['L_25_0008'] : ((isset($MSG['25_0008'])) ? $MSG['25_0008'] : '{ L_25_0008 }')); ?></h4>
					<div class="rounded-bottom">
						<ul class="menu">
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/currency.php"><?php echo ((isset($this->_rootref['L_currency_settings'])) ? $this->_rootref['L_currency_settings'] : ((isset($MSG['currency_settings'])) ? $MSG['currency_settings'] : '{ L_currency_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/time.php"><?php echo ((isset($this->_rootref['L_time_settings'])) ? $this->_rootref['L_time_settings'] : ((isset($MSG['time_settings'])) ? $MSG['time_settings'] : '{ L_time_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/buyitnow.php"><?php echo ((isset($this->_rootref['L_2__0025'])) ? $this->_rootref['L_2__0025'] : ((isset($MSG['2__0025'])) ? $MSG['2__0025'] : '{ L_2__0025 }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/defaultcountry.php"><?php echo ((isset($this->_rootref['L_default_country'])) ? $this->_rootref['L_default_country'] : ((isset($MSG['default_country'])) ? $MSG['default_country'] : '{ L_default_country }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/counters.php"><?php echo ((isset($this->_rootref['L_counter_settings'])) ? $this->_rootref['L_counter_settings'] : ((isset($MSG['counter_settings'])) ? $MSG['counter_settings'] : '{ L_counter_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/multilingual.php"><?php echo ((isset($this->_rootref['L_multilingual_support'])) ? $this->_rootref['L_multilingual_support'] : ((isset($MSG['multilingual_support'])) ? $MSG['multilingual_support'] : '{ L_multilingual_support }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/catsorting.php"><?php echo ((isset($this->_rootref['L_category_sorting'])) ? $this->_rootref['L_category_sorting'] : ((isset($MSG['category_sorting'])) ? $MSG['category_sorting'] : '{ L_category_sorting }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/metatags.php"><?php echo ((isset($this->_rootref['L_metatag_settings'])) ? $this->_rootref['L_metatag_settings'] : ((isset($MSG['metatag_settings'])) ? $MSG['metatag_settings'] : '{ L_metatag_settings }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/contactseller.php"><?php echo ((isset($this->_rootref['L_contact_seller'])) ? $this->_rootref['L_contact_seller'] : ((isset($MSG['contact_seller'])) ? $MSG['contact_seller'] : '{ L_contact_seller }')); ?></a></li>
							<li><a href="<?php echo (isset($this->_rootref['SITEURL'])) ? $this->_rootref['SITEURL'] : ''; ?>admin/buyerprivacy.php"><?php echo ((isset($this->_rootref['L_bidder_privacy'])) ? $this->_rootref['L_bidder_privacy'] : ((isset($MSG['bidder_privacy'])) ? $MSG['bidder_privacy'] : '{ L_bidder_privacy }')); ?></a></li>
						</ul>
					</div>
				</div>
				<div class="box">
					<h4 class="rounded-top"><?php echo ((isset($this->_rootref['L_1061'])) ? $this->_rootref['L_1061'] : ((isset($MSG['1061'])) ? $MSG['1061'] : '{ L_1061 }')); ?></h4>
					<div class="rounded-bottom">
						<form name="anotes" action="" method="post">
							<textarea rows="15" name="anotes" class="anotes"><?php echo (isset($this->_rootref['ADMIN_NOTES'])) ? $this->_rootref['ADMIN_NOTES'] : ''; ?></textarea>
							<input type="hidden" name="csrftoken" value="<?php echo (isset($this->_rootref['_CSRFTOKEN'])) ? $this->_rootref['_CSRFTOKEN'] : ''; ?>">
							<input type="submit" name="act" value="<?php echo ((isset($this->_rootref['L_submit'])) ? $this->_rootref['L_submit'] : ((isset($MSG['submit'])) ? $MSG['submit'] : '{ L_submit }')); ?>">
						</form>
					</div>
				</div>