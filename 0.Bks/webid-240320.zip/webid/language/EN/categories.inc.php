<?php
$category_names = array (
  1 => 'All',
  199 => 'Commercial and rescue R.I.B.s',
  201 => 'Outboard Engines',
  200 => 'Racing R.I.B.s',
  198 => 'Sports and cruising R.I.B.s',
);

$category_plain = array (
  201 => 'Outboard Engines',
  200 => 'Racing R.I.B.s',
  199 => 'Commercial and rescue R.I.B.s',
  198 => 'Sports and cruising R.I.B.s',
);
