Dear {S_NAME},

The following auctions you posted at {SITENAME} closed yesterday.

{REPORT}


An email has been sent to the winner(s) with your email address.

If you have received this message in error, please reply to this email,
write to {ADMINMAIL}, or visit {SITENAME} at {SITE_URL}.
