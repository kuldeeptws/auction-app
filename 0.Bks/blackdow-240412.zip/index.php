<?php
// Powered by ProSite
if (function_exists('ini_set')) @ini_set('opcache.enable', '0');
include dirname(__FILE__).'/sitepro/index.php';
?>