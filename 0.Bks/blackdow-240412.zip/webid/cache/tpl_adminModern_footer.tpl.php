<br>
		<div class="copyright">
			<?php echo ((isset($this->_rootref['L_COPY'])) ? $this->_rootref['L_COPY'] : ((isset($MSG['COPY'])) ? $MSG['COPY'] : '{ L_COPY }')); ?>
			Powered by <a href="http://webidsupport.4up.eu/">WeBid</a> &copy; 2008 - <?php echo ((isset($this->_rootref['L_COPY_YEAR'])) ? $this->_rootref['L_COPY_YEAR'] : ((isset($MSG['COPY_YEAR'])) ? $MSG['COPY_YEAR'] : '{ L_COPY_YEAR }')); ?> <a href="http://webidsupport.4up.eu/">WeBid</a>
		</div>
	</div>
</body>
</html>