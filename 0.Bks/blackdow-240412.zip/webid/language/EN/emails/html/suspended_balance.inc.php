Dear {NAME},<br>
<br>
Your account on {SITENAME} has been suspended because you have exceeded the maximum debt limit allowed.<br>
<br>
Your balance is: {BALANCE}<br>
<br>
In order to reactivate your account, you will need to clear your account balance.<br>
Please visit the link below to access the payment page.<br>
<a href="{OUTSTANDING}">{OUTSTANDING}</a>