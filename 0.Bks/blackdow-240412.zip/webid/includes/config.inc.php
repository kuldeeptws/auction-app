<?php
$DbHost	 = "localhost";
$DbDatabase = "blackdow_webid";
$DbUser	 = "blackdow_brutus";
$DbPassword = "Wonder@132dfsddcd";
$DBPrefix	= "webid_";
$main_path = "/home/blackdow/public_html/webid/";
$MD5_PREFIX = "40dc4cfcfea8ed69e8c4d7cc0600b880";
?>